﻿using WebApplication1.Models.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class User
    {
        int userID;
        string fullname;
        string username;
        string password;
        string gender;
        int age;
        string city;
        int points;
        string email;
        string[] preferedGenres;


        public User() { }

        public User(int userID, string fullname, string username, string password, string gender, int age, string city, int points, string email, string[] preferedGenres )
        {
            this.userID = userID;
            this.fullname = fullname;
            this.username = username;
            this.password = password;
            this.gender = gender;
            this.age = age;
            this.city = city;
            this.points = points;
            this.email = email;
            this.preferedGenres = preferedGenres;
        }


        public int UserID { get => userID; set => userID = value; }
        public string Fullname { get => fullname; set => fullname = value; }
        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }
        public string Gender { get => gender; set => gender = value; }
        public int Age { get => age; set => age = value; }
        public string City { get => city; set => city = value; }
        public int Points { get => points; set => points = value; }
        public string Email { get => email; set => email = value; }
        public string [] PreferedGenres { get => preferedGenres; set => preferedGenres = value; }

        public List<User> getUsers()
        {
            DBServices dbs = new DBServices();
            return dbs.getUsers();
        }

        public int addNewUser(User user)
        {
            DBServices dbs = new DBServices();
            return dbs.addUser(user);

        }

        public int CheckLoginData(string username, string password)
        {
            DBServices dbs = new DBServices();
            return dbs.CheckLoginData(username, password);
           
        }

        public int deleteUser(int userID)
        {
            DBServices dbs = new DBServices();
            return dbs.deleteUser(userID);
        }
    }
}