﻿using WebApplication1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebApplication1.Controllers
{
    public class UserController : ApiController
    {
        // GET api/<controller>
        public List<User> Get()
        {
            User user = new User();
            return user.getUsers();

        }


       
        // POST api/<controller>
        [HttpPost]
        public void Post([FromBody]User user)

        {

            user.addNewUser(user);

        }

        // PUT api/<controller>/5
        [HttpPut]
        public void Put(int id, [FromBody]User user)
        {

        }

        // DELETE api/<controller>/5
        public void Delete([FromBody]int id)
        {
            User user = new User();
            user.deleteUser(id);
        }


        
    }
}